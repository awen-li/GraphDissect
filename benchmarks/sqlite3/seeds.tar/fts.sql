CREATE VIRTUAL TABLE f USING fts5(content);
INSERT INTO f VALUES('hello world');
SELECT * FROM f WHERE f MATCH 'hello';

