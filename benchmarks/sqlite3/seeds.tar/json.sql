SELECT json_extract('{"a":[1,2]}', '$.a[0]');
